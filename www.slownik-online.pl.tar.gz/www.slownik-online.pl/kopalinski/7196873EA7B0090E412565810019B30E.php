<html><head>


<script type="text/javascript" src="/static/js/analytics.js"></script>

<link type="text/css" rel="stylesheet" href="/static/css/banner-styles.css"/>

<meta http-equiv=content-type content="text/html; charset=utf-8">
<title>propeller</title>
<meta name="description" content="Słownik wyrazów obcych Władysława Kopalińskiego on-line">
<meta name="keywords" content="propeller">
<link rel="stylesheet" href="http://www.slownik-online.pl/dea.css">
<script language="JavaScript">
<!--
function CSnd(x, _sndObj, sndFile) { //v3.0
var i, method = "", sndObj = eval(_sndObj);
if (sndObj != null) {
if (navigator.appName == 'Netscape') method = "play";
    else {
      if (window.MM_WMP == null) {
        window.MM_WMP = false;
        for(i in sndObj) if (i == "ActiveMovie") {
          window.MM_WMP = true; break;
      } }
      if (window.MM_WMP) method = "play";
      else if (sndObj.FileName) method = "run";
  } }
  if (method) eval(_sndObj+"."+method+"()");
  else window.location = sndFile;
}
//-->
</script>
</head><body>



<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<META NAME="Description" CONTENT="Słownik wyrazów obcych Władysława Kopalińskiego">
<link href="http://www.slownik-online.pl/dea.css" rel=stylesheet type=text/css>
<title>S&#322ownik wyraz&#243w obcych W&#322adys&#322awa Kopali&#324skiego</title>

<!-- Cookie Policy -->	
<script type="text/javascript" src="http://www.slownik-online.pl/js_jquery/jquery-1.8.3.min.js"></script> 
<link rel="stylesheet" href="http://www.slownik-online.pl/js_cookie/divante.cookies.min.css" type="text/css" media="all" />

</head>

 <body bgcolor="#041F57" text="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"  onLoad=""> 
<!-- <body bgcolor="#000000" text="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"  onLoad=""> -->

  
<table width="91%" border="0" cellspacing="0" cellpadding="0" align="center" height="184">
  <tr>
      
    <td height="268"> 
      <table border="0" align="center" cellspacing="0" cellpadding="0" height="180">
        <tr> 
            
          <td width="157" height="47"><img src="http://www.slownik-online.pl/obrazki/m01.gif" width="157" height="56" border="0"></td>
           <td width="441" height="47"><img src="http://www.slownik-online.pl/obrazki/m02.gif" width="441" height="56" border="0"></td> 
          <!-- <td width="441" height="47">&nbsp;</td>		-->			
          <td width="181" height="47"></td>
          </tr>
          <tr>
            
          <td width="157" height="43"><img src="http://www.slownik-online.pl/obrazki/m11.gif" width="157" height="42"></td>   
          <td width="441" height="43"><img src="http://www.slownik-online.pl/obrazki/m12.gif" width="441" height="42"></td>
            
          <td width="181" height="43">&nbsp;</td>
          </tr>
          <tr>
            
          <td width="157" height="251"> 
            <div align="center">
              <table width="100%" border="0" height="100%" align="left" cellspacing="0" cellpadding="0">
                <tr>&nbsp;</tr>
		
		
		<!-- <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="120" height="270" id="banner" align="middle">
		<param name="allowScriptAccess" value="sameDomain" />
				 <param name="movie" value="http://www.deagostini.pl/banner_ferrari.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#041F57" /><embed src="http://www.deagostini.pl/banner_ferrari.swf" quality="high" bgcolor="#041F57" width="120" height="270" name="banner" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /> 
		<param name="movie" value="http://www.deagostini.pl/_banner_ferrari.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#000000" /><embed src="http://www.deagostini.pl/banner_ferrari.swf" quality="high" bgcolor="#041F57" width="120" height="270" name="banner" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
		</object> -->
		
		<!--
<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0' width='120' height='300'>
													 <param name=movie value='http://www.deagostini.pl/nx_display/elementy/banner_me.swf'>
													 <param name='wmode' value='opaque' /><param name='quality' value='high'>
													 <embed src='http://www.deagostini.pl/nx_display/elementy/banner_me.swf' quality=high wmode='opaque' pluginspage='http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash' type='application/x-shockwave-flash' width='120' height='300'>
													 </embed> 
													 </object>		-->
		

              </table>
            </div>
            <p align="center">Z internetowej wersji S&#322ownika mog&#261 Pa&#324stwo 
              korzysta&#263 dzi&#281ki:</p>
            
						
						

	</td>
           <td width="441" height="251"  align="center" valign="top" bgcolor="#336699"> 
         <!-- <td width="441" height="251"  align="center" valign="top" bgcolor="#000000"> -->         
            <table width="100%" border="0" height="100%" align="top">
              <tr> 
                <td height="40" valign="top"> &nbsp; 
                  <form name="form1" action="http://www.slownik-online.pl/cgibin/search">
                    <p align="left"> wpisz s&#322owo lub wyra&#380enie: 
                      <input type=hidden name="charset" value="utf-8">
					  <input type="text" name="words">
                      <input type="submit" name="Submit" value="Szukaj">
                    </p>
                    
                  </form>
                </td>
              </tr>
              <tr> 
                <td valign="top"> 
				
<table border=0>
<tr><td width=20>
<A name="7196873EA7B0090E412565810019B30E">
&nbsp;
</td><td>
<B><FONT CLASS="10ptGeorgia" >propeller</FONT></B><FONT CLASS="10ptGeorgia" > </FONT><I><FONT CLASS="10ptGeorgia" >dawn.</FONT></I><FONT CLASS="10ptGeorgia" > śmigło.</FONT>
</td></tr>
<TR><TD VALIGN=TOP><FONT CLASS="8ptGeorgia">&nbsp;</FONT></TD>
<TD VALIGN=TOP><P><FONT CLASS="8ptGeorgia">Etym.&nbsp;-&nbsp;<FONT CLASS="8ptGeorgia" >ang. 'jw.' z łac. </FONT><I><FONT CLASS="8ptGeorgia" >propellere</FONT></I><FONT CLASS="8ptGeorgia" > 'pchać, ciągnąć naprzód'; </FONT><I><FONT CLASS="8ptGeorgia" >pro</FONT></I><FONT CLASS="8ptGeorgia" > 'przed', por.</FONT><A HREF="/kopalinski/A2BBF5AFC4F09417C1256581000D884F.php"><FONT CLASS="8ptGeorgia" > pro- 2</FONT></A><FONT CLASS="8ptGeorgia" >; </FONT><I><FONT CLASS="8ptGeorgia" >pellere</FONT></I><FONT CLASS="8ptGeorgia" >, zob. </FONT><A HREF="/kopalinski/078ce2b5b587789dc1256581007eb878.php"><FONT CLASS="8ptGeorgia" >puls</FONT></A><FONT CLASS="8ptGeorgia" >.</FONT>
</FONT></P></TD></TR>
</table>
 
				  
				  
                </td>
              </tr>
            </table>
            
     
          </td>
            
          <td width="181" height="251" valign="top"> 
            <p align="center">
<object classid='clsid:d27cdb6e-ae6d-11cf-96b8-444553540000' codebase='http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0' width='120' height='300'>
													 <param name=movie value='../bach_banner.swf'>
													 <param name='wmode' value='opaque' /><param name='quality' value='high'>
													 
													 </embed> 
													 </object>

</p>
            <p align="center">&nbsp;</p>
            <p align="center">&nbsp;</p>
            </td>
          </tr>
        </table>
        
    </td>
    </tr>
  </table>

<table width="780" border="0" height="8" background="http://www.slownik-online.pl/obrazki/pasek_dol.gif" align="center">
  <tr>
    <td>
      <div align="center"><a href="http://www.slownik-online.pl/index.php">Strona g&#322&#243wna</a>  | <a href="http://www.slownik-online.pl/indeks_hasel.php">Indeks</a> | <a href="http://www.slownik-online.pl/oslowniku.php">O 
        S&#322owniku</a></div>
    </td>
  </tr>
</table>



<!-- Cookie Policy -->
    <script type="text/javascript" src="http://www.slownik-online.pl/js_cookie/divante.cookies.min.js"></script>
    <script>window.jQuery.cookie || document.write('<script src="../js_cookie/jquery.cookie.min.js"><\/script>')</script>
    <script type="text/javascript">
        jQuery.divanteCookies.render({
            privacyPolicy : true,
            cookiesPageURL : 'http://www.politykacookie.deagostini.pl/polityka_cookie.php'
        });
    </script>
		
</body>
</html>