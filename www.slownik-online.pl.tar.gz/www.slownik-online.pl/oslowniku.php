<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>


<script type="text/javascript" src="/static/js/analytics.js"></script>

<link type="text/css" rel="stylesheet" href="/static/css/banner-styles.css"/>


<META HTTP-EQUIV="Content-type" CONTENT="text/html; charset=utf-8">
<META NAME="Description" CONTENT="SĹ‚ownik wyrazĂĹw obcych WĹ‚adysĹ‚awa KopaliĹ„skiego">
<link href="/dea.css" rel=stylesheet type=text/css>
<title>S&#322ownik wyraz&#243w obcych W&#322adys&#322awa Kopali&#324skiego</title>

<!-- Cookie Policy -->	
<script type="text/javascript" src="/js_jquery/jquery-1.8.3.min.js"></script> 
<link rel="stylesheet" href="/js_cookie/divante.cookies.min.css" type="text/css" media="all" />

</head>

 <body bgcolor="#041F57" text="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"  onLoad="">



 
<!-- <body bgcolor="#000000" text="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"  onLoad=""> -->

  
<table width="91%" border="0" cellspacing="0" cellpadding="0" align="center" height="184">
  <tr>
      
    <td height="268"> 
      <table border="0" align="center" cellspacing="0" cellpadding="0" height="180">
        <tr> 
            
          <td width="157" height="47"><img src="/obrazki/m01.gif" width="157" height="56" border="0"></td>
           <td width="441" height="47"><img src="/obrazki/m02.gif" width="441" height="56" border="0"></td>
          <!-- <td width="441" height="47">&nbsp;</td>	-->				
          <td width="181" height="47"></td>
          </tr>
          <tr>
            
          <td width="157" height="43"><img src="/obrazki/m11.gif" width="157" height="42"></td>   
          <td width="441" height="43"><img src="/obrazki/m12.gif" width="441" height="42"></td>
            
          <td width="181" height="43">&nbsp;</td>
          </tr>
          <tr>
            
          <td width="157" height="251"> 
            <div align="center">
              <table width="100%" border="0" height="100%" align="left" cellspacing="0" cellpadding="0">
                <tr>  </tr>
              </table>
            </div>
            <p align="center"></p>
            <p align="center"></p>
						

			
</a></p>
            <p align="center">&nbsp;</p>
            </td>
           <td width="441" height="251"  align="center" valign="top" bgcolor="#336699"> 
         <!--   <td width="441" height="251"  align="center" valign="top" bgcolor="#000000">	-->				
            <table width="100%" border="0" height="100%" align="top">
              <tr> 
                <td height="40" valign="top"> &nbsp; 
                  <form name="form1" action="/cgibin/search/index.php">
                    <p align="left"> wpisz s&#322owo lub wyra&#380enie: 
                      <input type=hidden name="charset" value="utf-8">
					  <input type="text" name="words">
                      <input type="submit" name="Submit" value="Szukaj">
                    </p>
                    
                  </form>
                </td>
              </tr>
              <tr> 
                <td valign="top">  				

<DIV ALIGN="CENTER"><B>Władysław Kopaliński</B><BR>
<B>Słownik wyrazów obcych i zwrotów obcojęzycznych</B><BR>
pierwsze wydanie w Internecie<BR>
<BR>

<BR>

<BR>

</DIV>
 				
 				
 				
 				
 				
				 
				  
				  
                </td>
              </tr>
            </table>
            
     
          </td>
            
          <td width="181" height="251" valign="top"> 
            <p align="center">
						

</p>
            <p align="center">&nbsp;</p>
            <p align="center">&nbsp;</p>
            </td>
          </tr>
        </table>
        
    </td>
    </tr>
  </table>

<table width="780" border="0" height="8" background="http://slownik-online.pl/obrazki/pasek_dol.gif" align="center">
  <tr>
    <td>
      <div align="center"><a href="/index.php">Strona g&#322&#243wna</a>  | <a href="/indeks_hasel.php">Indeks</a> | <a href="/oslowniku.php">O 
        S&#322owniku</a></div>
    </td>
  </tr>
</table>


<br />
<center>

</center>


<!-- Cookie Policy -->
    <script type="text/javascript" src="/js_cookie/divante.cookies.min.js"></script>
    <script>window.jQuery.cookie || document.write('<script src="js_cookie/jquery.cookie.min.js"><\/script>')</script>
    <script type="text/javascript">
        jQuery.divanteCookies.render({
            privacyPolicy : true,
            cookiesPageURL : 'http://www.politykacookie.deagostini.pl/polityka_cookie.php'
        });
    </script>
		
</body>
</html>